const uint8_t help_js[] = R"rawliteral(
window.addEventListener("load", function () {
    UpdateVersion();
});

)rawliteral";