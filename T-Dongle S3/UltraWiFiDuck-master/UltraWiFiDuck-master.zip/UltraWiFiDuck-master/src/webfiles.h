#pragma once

#include "html_credits_html.h"
#include "html_error404_html.h"
#include "html_index_html.h"
#include "html_help_html.h"
#include "html_help_js.h"
#include "html_index_js.h"
#include "html_script_js.h"
#include "html_settings_html.h"
#include "html_settings_js.h"
#include "html_style_css.h"
#include "html_favicon_ico.h"
#include "html_bmc_qr_png.h"
