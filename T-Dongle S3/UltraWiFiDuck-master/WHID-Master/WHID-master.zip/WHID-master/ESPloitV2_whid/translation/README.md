This is Keyboard.cpp that work with italian ALT+GR commands
Thanks to CiriousJocker https://github.com/NicoHood/HID/issues/92


