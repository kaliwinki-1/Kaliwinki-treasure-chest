# Example - Simple UI

Example of using the file system API to make a simple script selection user interface.

## Set up
1. Copy autorun.ds onto the SD card
2. Copy select.png files onto the SD card

## Usage
1. Plug in device
2. Use button to select file to run
3. Hold button to select file