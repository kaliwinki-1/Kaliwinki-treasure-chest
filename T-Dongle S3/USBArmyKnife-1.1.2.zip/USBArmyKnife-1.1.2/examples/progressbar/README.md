# Example - Progress bar

Example of how to show a simple Hollywood style progress bar, useful for multistage attacks

**Note** The images to be displayed have been developed for the smallest screen supported. If you are using a device with a larger screen you will encounter unfilled areas of the display.

## Set up
1. Copy autorun.ds onto the SD card
2. Copy all the PNG files onto the SD card

## Usage
1. Plug in device