# Example - WiFi deauth and crypt capture

Example of using the ESP32 Marauder commands to deauth client and capture their handshakes to a file. These can then we cracked offline for the WPA/WPA2 password.



https://github.com/user-attachments/assets/a01736eb-fd8c-41bc-9caa-dd83cbc9d9b6



## Set up
1. Copy autorun.ds onto the SD card

## Usage
1. Plug in device
2. Press button
3. Wait until you see some packets in the progress bar
4. Click button
