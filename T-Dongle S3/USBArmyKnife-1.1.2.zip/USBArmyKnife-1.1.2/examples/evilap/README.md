# Example - EvilAP

## Set up
1. Copy autorun.ds onto the SD card



https://github.com/user-attachments/assets/cb44a0ac-b093-4530-a04f-375bdf3f1017



## Usage
1. Plug in device
1. Visit the access point 'AppleFreeWiFi'
1. Type your password in
