#ifdef NO_TOUCH
#include "HardwareTouch.h"

namespace Devices
{
  HardwareTouch Touch;
}

HardwareTouch::HardwareTouch()
{
}

void HardwareTouch::loop(Preferences& prefs)
{
}

void HardwareTouch::begin(Preferences &prefs)
{
}

#endif