#ifdef NO_IR
#include "HardwareIR.h"

namespace Devices
{
    HardwareIR IR;
}

HardwareIR::HardwareIR()
{
}

void HardwareIR::begin(Preferences &prefs)
{
}

void HardwareIR::loop(Preferences &prefs)
{
}
#endif