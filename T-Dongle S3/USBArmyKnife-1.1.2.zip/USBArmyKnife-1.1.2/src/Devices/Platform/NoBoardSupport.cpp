#if !defined(LILYGO_T_WATCH_S3) && !defined(EVIL_CROW_CABLE_WIND)
#include "BoardSupport.h"

BoardSupport::BoardSupport()
{
}

void BoardSupport::begin(Preferences &prefs)
{

}

void BoardSupport::loop(Preferences &prefs)
{
    
}
#endif