# AuxiliaryComponent

Auxiliary components are usually external devices that aren't a permanent part of a device itself.