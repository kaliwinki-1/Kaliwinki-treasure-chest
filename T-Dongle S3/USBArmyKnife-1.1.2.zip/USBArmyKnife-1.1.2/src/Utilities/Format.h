#pragma once

#include <Preferences.h>

void AskFormatSD(Preferences& prefs);