#pragma once
const char GIT_COMMIT_HASH[] = "Error - version file not regenerated    ";